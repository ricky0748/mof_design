# MOF design task design_720d2362be5a46b2

Status: completed

Engine: egmof

Scene: egmof.co2_uptake_298k_2_5bar

Requested: 2; attempts: 2; accepted: 2.

Constraints are applied by explicit post-generation checks. See candidates.json for all checks and rejections. Native target values are checkpoint conditions, not independently measured performance.

Use manifest.json to locate accepted CIFs and verify hashes. Remaining requested slots are reported without automatic unbounded resampling.
