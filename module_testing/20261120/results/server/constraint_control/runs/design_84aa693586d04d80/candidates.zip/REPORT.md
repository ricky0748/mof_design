# MOF design task design_84aa693586d04d80

Status: failed

Engine: mofflow2_linker

Scene: mofflow2.co2_working_capacity

Requested: 1; attempts: 1; accepted: 0.

Constraints are applied by explicit post-generation checks. See candidates.json for all checks and rejections. Native target values are checkpoint conditions, not independently measured performance.

Use manifest.json to locate accepted CIFs and verify hashes. Remaining requested slots are reported without automatic unbounded resampling.
