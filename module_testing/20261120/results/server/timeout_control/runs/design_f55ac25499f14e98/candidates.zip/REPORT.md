# MOF design task design_f55ac25499f14e98

Status: timed_out

Engine: egmof

Scene: egmof.co2_uptake_298k_2_5bar

Requested: 1; attempts: 0; accepted: 0.

Constraints are applied by explicit post-generation checks. See candidates.json for all checks and rejections. Native target values are checkpoint conditions, not independently measured performance.

Use manifest.json to locate accepted CIFs and verify hashes. Remaining requested slots are reported without automatic unbounded resampling.
