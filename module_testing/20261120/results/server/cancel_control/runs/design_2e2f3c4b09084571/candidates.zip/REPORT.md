# MOF design task design_2e2f3c4b09084571

Status: cancelled

Engine: mofflow2_linker

Scene: mofflow2.co2_working_capacity

Requested: 1; attempts: 0; accepted: 0.

Constraints are applied by explicit post-generation checks. See candidates.json for all checks and rejections. Native target values are checkpoint conditions, not independently measured performance.

Use manifest.json to locate accepted CIFs and verify hashes. Remaining requested slots are reported without automatic unbounded resampling.
