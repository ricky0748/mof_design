# MOF design task design_99c3c75f7ad84848

Status: completed

Engine: mofflow2_linker

Scene: mofflow2.co2_working_capacity

Requested: 2; attempts: 2; accepted: 2.

Constraints are applied by explicit post-generation checks. See candidates.json for all checks and rejections. Native target values are checkpoint conditions, not independently measured performance.

Use manifest.json to locate accepted CIFs and verify hashes. Remaining requested slots are reported without automatic unbounded resampling.
